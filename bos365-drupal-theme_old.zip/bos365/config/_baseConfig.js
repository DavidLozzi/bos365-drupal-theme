/*
USE this template to create your config for build.
Copy this file and rename to yours.config.js, and git will ignore it
*/

module.exports = {
    FTP_CONNECTION: {
            host: 'the.server.name.com',
            user: 'username',
            pass: 'p@ssw0rd'
        },
    FTP_PATH: '/path/to/root/of/theme/folder'
}